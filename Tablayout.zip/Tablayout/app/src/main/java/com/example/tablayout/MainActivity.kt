package com.example.tablayout

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.tool)
        setSupportActionBar(toolbar)

        val tabLayout: TabLayout = findViewById(R.id.tab)
        val viewPager: ViewPager = findViewById(R.id.viewpager)

        val adapter = MyAdapter(supportFragmentManager)
        adapter.setdata(ChatFragment(), "Chat")
        adapter.setdata(StatusFragment(), "Status")
        adapter.setdata(CallFragment(), "Call")

        viewPager.adapter = adapter
        tabLayout.setupWithViewPager(viewPager)
    }
}
