package com.example.tablayout


class Model (var image:Int, var title:String, var subtitle: String) {
}